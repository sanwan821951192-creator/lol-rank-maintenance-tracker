@echo off
setlocal
set "BUNDLED_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
set "PYTHONIOENCODING=utf-8"
chcp 65001 >nul
echo League match query service. Keep this window open while querying.
echo Open and sign in to the League of Legends client first.
echo.
if exist "%BUNDLED_PY%" (
  "%BUNDLED_PY%" -B "%~dp0bridge.py" --allow-origin https://sanwan821951192-creator.github.io
) else (
  py -3 -B "%~dp0bridge.py" --allow-origin https://sanwan821951192-creator.github.io
)
echo.
echo Query service stopped. Press any key to close this window.
pause >nul
