import json
import threading
import unittest
import urllib.error
import urllib.request
from unittest import mock

import bridge


def game(number, queue=420, created=1760000000000, duration=1800):
    return {'json': {'gameId': number, 'queueId': queue, 'gameCreation': created,
                     'gameEndTimestamp': created + duration * 1000,
                     'endOfGameResult': 'GameComplete', 'platformId': 'HN1'}}


def fake_lcu(path):
    if path == '/lol-rso-auth/v1/authorization':
        return {'currentPlatformId': 'HN1'}
    if path == '/entitlements/v1/token':
        return {'accessToken': 'synthetic-token'}
    if path == '/lol-league-session/v1/league-session-token':
        return 'synthetic-session'
    if 'summoners?' in path:
        return {'puuid': 'synthetic-puuid', 'gameName': 'Sample', 'tagLine': 'CN'}
    raise AssertionError('unexpected request')


def fake_riot(path):
    return [{'puuid': 'synthetic-puuid', 'alias': {'game_name': 'Sample', 'tag_line': 'CN'}}]


def fake_summoner(host, platform, puuid, token):
    return [{'puuid': puuid}]


real_lookup = bridge.match_lookup
def test_lookup(*args, **kwargs):
    kwargs.setdefault('get_riot', fake_riot)
    kwargs.setdefault('get_summoner', fake_summoner)
    return real_lookup(*args, **kwargs)
bridge.match_lookup = test_lookup


class MatchTests(unittest.TestCase):
    def test_bilgewater_alias_selects_alliance_four_from_other_client(self):
        def tj100_lcu(path):
            if path == '/lol-rso-auth/v1/authorization':
                return {'currentPlatformId': 'TJ100'}
            return fake_lcu(path)
        result = bridge.match_lookup('Sample#CN', region='比尔吉沃特', get=tj100_lcu,
                                     get_sgp=lambda *args: {'games': []})
        self.assertEqual(result['region'], 'TJ100')
        seen = []
        result = bridge.match_lookup('Sample#CN', region='比尔吉沃特', get=fake_lcu,
                                     get_sgp=lambda host, *args: seen.append(host) or {'games': []})
        self.assertEqual(result['region'], 'TJ100')
        self.assertEqual(seen, ['tj100-sgp.lol.qq.com'])

    def test_repeat_page_is_incomplete_and_deduplicated(self):
        calls = []
        def fake_sgp(host, puuid, start, token):
            calls.append(start)
            return {'games': [game(i, created=1760000000000-i*1000) for i in range(1, 21)]}
        result = bridge.match_lookup('Sample#CN', '2020-01-01T00:00:00Z', '艾欧尼亚', get=fake_lcu, get_sgp=fake_sgp)
        self.assertEqual(len(result['matches']), 20)
        self.assertFalse(result['complete'])
        self.assertIn('重复', result['reason'])
        self.assertEqual(calls[-1], 20)
        self.assertIsInstance(result['matches'][0]['gameId'], str)
        self.assertNotIn('puuid', json.dumps(result))

    def test_identity_mismatch_fails_closed(self):
        def fake(path):
            return [{'puuid': 'abc', 'alias': {'game_name': 'Other', 'tag_line': 'CN'}}]
        with self.assertRaises(bridge.BridgeError):
            bridge.match_lookup('Sample#CN', region='HN1', get=fake_lcu, get_riot=fake)

    def test_target_region_must_contain_the_player(self):
        with self.assertRaises(bridge.BridgeError):
            bridge.match_lookup('Sample#CN', region='HN10', get=fake_lcu, get_summoner=lambda *a: [])

    def test_detail_fields_use_only_matching_participant(self):
        row = game(1)
        row['json'].update({'gameMode': 'CLASSIC', 'gameDuration': 1400, 'participants': [
            {'puuid': 'other', 'championName': 'Wrong', 'win': False},
            {'puuid': 'synthetic-puuid', 'championName': 'Ahri', 'championId': 103,
             'kills': 3, 'deaths': 2, 'assists': 4, 'win': True}]})
        result = bridge.match_lookup('Sample#CN', region='HN1', get=fake_lcu, get_sgp=lambda *a: {'games': [row]})
        match = result['matches'][0]
        self.assertEqual((match['championName'], match['kills'], match['win']), ('Ahri', 3, True))
        self.assertEqual(match['durationSeconds'], 1400)
        self.assertNotIn('items', match)
        self.assertNotIn('puuid', json.dumps(result))

    def test_afk_evidence_is_raw_and_matches_the_player(self):
        row = game(1)
        row['json'].update({'gameDuration': 1400, 'participants': [
            {'puuid': 'other', 'wasAfk': False, 'wasSevereTransgressor': False, 'timePlayed': 10},
            {'puuid': 'synthetic-puuid', 'wasAfk': True, 'wasSevereTransgressor': False, 'timePlayed': 1400}]})
        result = bridge.match_lookup('Sample#CN', region='HN1', get=fake_lcu, get_sgp=lambda *a: {'games': [row]})
        match = result['matches'][0]
        self.assertIs(match['wasAfk'], True)
        self.assertIs(match['wasSevereTransgressor'], False)
        self.assertEqual(match['timePlayed'], 1400)
        self.assertEqual(match['durationSeconds'], 1400)
        self.assertEqual(match['endOfGameResult'], 'GameComplete')
        self.assertEqual(match['result'], match['endOfGameResult'])

    def test_absent_invalid_or_ambiguous_evidence_is_omitted(self):
        row = game(1)
        row['json'].pop('endOfGameResult')
        row['json']['gameDuration'] = float('nan')
        row['json']['participants'] = [{'puuid': 'synthetic-puuid', 'wasAfk': 0,
                                        'wasSevereTransgressor': 'false', 'timePlayed': True}]
        result = bridge.match_lookup('Sample#CN', region='HN1', get=fake_lcu, get_sgp=lambda *a: {'games': [row]})
        match = result['matches'][0]
        for key in ('result', 'endOfGameResult', 'durationSeconds', 'wasAfk', 'wasSevereTransgressor', 'timePlayed'):
            self.assertNotIn(key, match)
        row['json']['participants'] = [
            {'puuid': 'synthetic-puuid', 'wasAfk': False, 'timePlayed': 100},
            {'puuid': 'synthetic-puuid', 'wasAfk': True, 'timePlayed': 10}]
        match = bridge.match_lookup('Sample#CN', region='HN1', get=fake_lcu, get_sgp=lambda *a: {'games': [row]})['matches'][0]
        self.assertNotIn('wasAfk', match)
        self.assertNotIn('timePlayed', match)

    def test_missing_game_fields_fail_closed(self):
        with self.assertRaises(bridge.BridgeError):
            bridge.match_lookup('Sample#CN', region='HN1', get=fake_lcu, get_sgp=lambda *a: {'games': [{'json': {'gameId': 123}}]})

    def test_window_coverage_and_real_end_time(self):
        pages = {
            0: [game(i, created=1760000000000-i*1000) for i in range(1, 21)],
            20: [game(i, created=1760000000000-i*1000) for i in range(21, 41)],
        }
        def fake_sgp(host, puuid, start, token):
            return {'games': pages[start]}
        threshold = bridge.iso_from_seconds((1760000000000-25000)/1000 + 1800)
        result = bridge.match_lookup('Sample#CN', threshold, '艾欧尼亚', get=fake_lcu, get_sgp=fake_sgp)
        self.assertTrue(result['complete'])
        self.assertEqual(len(result['matches']), 25)
        self.assertEqual(result['source'], 'SGP')
        self.assertEqual(result['region'], 'HN1')
        self.assertEqual(result['matches'][0]['endedAt'], bridge.iso_from_seconds((1760000000000-1000)/1000+1800))

    def test_short_page_and_unknown_region(self):
        result = bridge.match_lookup('Sample#CN', '2020-01-01T00:00:00Z', 'HN1', get=fake_lcu,
                                     get_sgp=lambda *a: {'games': [game(1)]})
        self.assertFalse(result['complete'])
        with self.assertRaises(bridge.BridgeError):
            bridge.match_lookup('Sample#CN', region='不存在的区', get=fake_lcu)

    def test_first_page_changes_before_completion(self):
        calls = 0
        def fake_sgp(host, puuid, start, token):
            nonlocal calls
            calls += 1
            return {'games': [game(i + (100 if calls > 1 else 0), created=1760000000000-i*1000) for i in range(1, 21)]}
        result = bridge.match_lookup('Sample#CN', '2026-01-01T00:00:00Z', 'HN1', get=fake_lcu, get_sgp=fake_sgp)
        self.assertFalse(result['complete'])
        self.assertIn('发生变化', result['reason'])

    def test_page_limit_is_incomplete(self):
        def fake_sgp(host, puuid, start, token):
            return {'games': [game(i, created=1760000000000-i*1000) for i in range(start+1, start+21)]}
        result = bridge.match_lookup('Sample#CN', '2020-01-01T00:00:00Z', 'HN1', get=fake_lcu, get_sgp=fake_sgp)
        self.assertFalse(result['complete'])
        self.assertIn('上限', result['reason'])

    def test_out_of_order_or_wrong_server_incomplete(self):
        def unordered(host, puuid, start, token):
            return {'games': [game(i, created=1760000000000+i*1000) for i in range(1, 21)]}
        result = bridge.match_lookup('Sample#CN', '2020-01-01T00:00:00Z', 'HN1', get=fake_lcu, get_sgp=unordered)
        self.assertFalse(result['complete'])
        wrong_server = game(1)
        wrong_server['json']['platformId'] = 'HN10'
        with self.assertRaises(bridge.BridgeError):
            bridge.match_lookup('Sample#CN', region='HN1', get=fake_lcu, get_sgp=lambda *args: {'games': [wrong_server]})

    def test_since_requires_timezone(self):
        with self.assertRaises(bridge.BridgeError):
            bridge.parse_since('2026-01-01T00:00:00')
        self.assertIsNotNone(bridge.parse_since('2026-01-01T00:00:00+08:00'))

    def test_origins(self):
        self.assertTrue(bridge.origin_valid('https://example.github.io'))
        self.assertTrue(bridge.origin_valid('http://127.0.0.1:8000'))
        for invalid in ('null', '*', 'https://github.io', 'https://example.github.io.evil.com', 'https://example.github.io/path', 'http://example.github.io'):
            self.assertFalse(bridge.origin_valid(invalid))


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.server = bridge.ThreadingHTTPServer(('127.0.0.1', 0), bridge.Handler)
        self.server.allowed_origin = 'https://example.github.io'
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = 'http://127.0.0.1:' + str(self.server.server_port)

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()

    def request(self, path, origin, method='GET', body=None):
        req = urllib.request.Request(self.url + path, data=body, method=method,
                                     headers={'Origin': origin, 'Content-Type': 'application/json'})
        try:
            return urllib.request.urlopen(req, timeout=2)
        except urllib.error.HTTPError as e:
            return e

    def test_access_and_response(self):
        with mock.patch.object(bridge, 'match_lookup', return_value={'ok': True, 'matches': [], 'complete': False, 'reason': 'test', 'observedAt': 'test'}):
            response = self.request('/api/matches', 'https://example.github.io', 'POST', b'{"riotId":"Example#CN"}')
            self.assertEqual(response.status, 200)
            self.assertEqual(response.headers['Access-Control-Allow-Origin'], 'https://example.github.io')
            self.assertFalse(json.load(response)['complete'])
        denied = self.request('/api/matches', 'https://evil.example', 'POST', b'{"riotId":"Example#CN"}')
        self.assertEqual(denied.status, 403)
        self.assertIsNone(denied.headers.get('Access-Control-Allow-Origin'))

    def test_preflight(self):
        response = self.request('/api/matches', 'https://example.github.io', 'OPTIONS')
        self.assertEqual(response.status, 204)
        self.assertEqual(response.headers['Access-Control-Allow-Private-Network'], 'true')


if __name__ == '__main__':
    unittest.main()
