import json
import threading
import unittest
import urllib.error
import urllib.request
from unittest import mock

import bridge


def game(number, queue=420, created=1760000000000, duration=1800):
    return {'gameId': number, 'queueId': queue, 'gameCreation': created, 'gameDuration': duration}


class MatchTests(unittest.TestCase):
    def test_repeat_page_is_incomplete_and_deduplicated(self):
        calls = []
        def fake(path):
            calls.append(path)
            if 'summoners?' in path:
                return {'puuid': 'example', 'gameName': 'Sample', 'tagLine': 'CN'}
            return {'games': {'games': [game(i) for i in range(1, 21)]}}
        result = bridge.match_lookup('Sample#CN', get=fake)
        self.assertEqual(len(result['matches']), 20)
        self.assertFalse(result['complete'])
        self.assertIn('重复页', result['reason'])
        self.assertIn('begIndex=20', calls[-1])
        self.assertIsInstance(result['matches'][0]['gameId'], str)
        self.assertNotIn('puuid', json.dumps(result))

    def test_identity_mismatch_fails_closed(self):
        with self.assertRaises(bridge.BridgeError):
            bridge.match_lookup('Sample#CN', get=lambda _: {'puuid': 'abc', 'gameName': 'Other', 'tagLine': 'CN'})

    def test_missing_game_fields_fail_closed(self):
        def fake(path):
            if 'summoners?' in path:
                return {'puuid': 'abc', 'gameName': 'Sample', 'tagLine': 'CN'}
            return {'games': {'games': [{'gameId': 123}]}}
        with self.assertRaises(bridge.BridgeError):
            bridge.match_lookup('Sample#CN', get=fake)

    def test_since_requires_timezone(self):
        with self.assertRaises(bridge.BridgeError):
            bridge.parse_since('2026-01-01T00:00:00')
        self.assertIsNotNone(bridge.parse_since('2026-01-01T00:00:00+08:00'))

    def test_origins(self):
        self.assertTrue(bridge.origin_valid('https://example.github.io'))
        self.assertTrue(bridge.origin_valid('http://127.0.0.1:8000'))
        for invalid in ('null', '*', 'https://github.io', 'https://example.github.io.evil.com', 'https://example.github.io/path', 'http://example.github.io'):
            self.assertFalse(bridge.origin_valid(invalid))


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.server = bridge.ThreadingHTTPServer(('127.0.0.1', 0), bridge.Handler)
        self.server.allowed_origin = 'https://example.github.io'
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = 'http://127.0.0.1:' + str(self.server.server_port)

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()

    def request(self, path, origin, method='GET', body=None):
        req = urllib.request.Request(self.url + path, data=body, method=method,
                                     headers={'Origin': origin, 'Content-Type': 'application/json'})
        try:
            return urllib.request.urlopen(req, timeout=2)
        except urllib.error.HTTPError as e:
            return e

    def test_access_and_response(self):
        with mock.patch.object(bridge, 'match_lookup', return_value={'ok': True, 'matches': [], 'complete': False, 'reason': 'test', 'observedAt': 'test'}):
            response = self.request('/api/matches', 'https://example.github.io', 'POST', b'{"riotId":"Example#CN"}')
            self.assertEqual(response.status, 200)
            self.assertEqual(response.headers['Access-Control-Allow-Origin'], 'https://example.github.io')
            self.assertFalse(json.load(response)['complete'])
        denied = self.request('/api/matches', 'https://evil.example', 'POST', b'{"riotId":"Example#CN"}')
        self.assertEqual(denied.status, 403)
        self.assertIsNone(denied.headers.get('Access-Control-Allow-Origin'))

    def test_preflight(self):
        response = self.request('/api/matches', 'https://example.github.io', 'OPTIONS')
        self.assertEqual(response.status, 204)
        self.assertEqual(response.headers['Access-Control-Allow-Private-Network'], 'true')


if __name__ == '__main__':
    unittest.main()
