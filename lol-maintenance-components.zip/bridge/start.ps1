param(
    [Parameter(Mandatory=$true)] [string] $AllowOrigin,
    [int] $Port = 8765
)
$ErrorActionPreference = 'Stop'
$bundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (Test-Path -LiteralPath $bundledPython) {
    & $bundledPython (Join-Path $PSScriptRoot 'bridge.py') --allow-origin $AllowOrigin --port $Port
} elseif (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 (Join-Path $PSScriptRoot 'bridge.py') --allow-origin $AllowOrigin --port $Port
} else {
    Write-Error '未找到 Python。请安装 Python 3.9 或更高版本后重试。'
}
