# 本机只读战绩桥接原型

此程序从本机已登录的英雄联盟客户端临时读取凭证，以 Akari 使用的 SGP 数据源查询战绩，供指定网页访问。它不读取账号密码、不保存客户端令牌、不修改游戏或云端数据，也不注册定时任务。它不是调用 Akari 的公开接口。

## 启动

打开并登录英雄联盟客户端，再在 PowerShell 中运行：

```powershell
cd D:\云顶ai\lol-maintenance-tracker\bridge
./start.ps1 -AllowOrigin https://你的GitHub用户名.github.io
```

上面的目录是本机项目位置；从 GitHub 下载压缩包后请改为解压出的 `bridge` 文件夹。将 origin 替换成网站真实地址的协议和主机部分，不带末尾斜杠或仓库路径。启动脚本优先使用本机 Codex 自带的 Python，若不存在则尝试 Windows 的 `py -3`；后者需要安装 Python 3.9 以上。若在本机调试网站，可填写 `http://127.0.0.1:8000`（端口需与网页一致）。监听地址固定为 `127.0.0.1:8765`。关闭终端即停止，程序不会随系统自动启动。网页与此程序必须在同一台电脑，且客户端保持登录。浏览器对 HTTPS 页面访问本机 HTTP 的策略可能限制功能，需在目标浏览器实测。

## API

仅允许启动参数指定的单一 Origin，拒绝其他 Origin 及非预期 Host。`GET /api/status` 检测客户端是否连接；`POST /api/matches` 接受 JSON：

```json
{"riotId":"游戏名#标签","region":"艾欧尼亚","since":"2026-10-01T00:00:00+08:00"}
```

`region` 必填，支持 HN1／艾欧尼亚、HN10／黑色玫瑰、TJ100／联盟四区／比尔吉沃特、TJ101／联盟五区、NJ100／联盟一区、GZ100／联盟二区、CQ100／联盟三区、BGP2／峡谷之巅。程序先使用 Riot Client 的别名查询解析身份，再向目标区的 SGP 确认该玩家存在，最后查询该区战绩；当前区服与目标区服可以不同，但跨区是否可用仍需真实账号验证。`since` 可省略；提供时必须带时区，只返回 SGP 报告的结束时间不早于它的对局。响应包括 `ok`、`matches`、`complete`、`reason`、`observedAt`、`source` 和 `region`；`observedAt` 为开始分页的时间。每场包含字符串 `gameId`、数字 `queueId`、UTC 格式的 `startedAt`、SGP 的 `endedAt` 和数据源的 `result`；如果源数据包含且能够对应查询玩家，还会返回 `championName`、`championId`、`kills`、`deaths`、`assists`、`win`、`items`，以及对局 `gameMode`、`durationSeconds`。缺失字段不推断。查询不返回账号名、PUUID 或令牌。出错时响应 `{"ok":false,"error":"说明"}`，附 HTTP 状态码。

实现参考 [LeagueAkari 的 Riot ID 解析与 SGP 查询](https://github.com/LeagueAkari/LeagueAkari/blob/56cdfde00e56148f4641d1a8cf86acb66e903124/src/renderer-shared/composables/useSummonerFetch.ts)；客户端凭证只在本机进程内使用，不上传到网站或数据库。LeagueAkari 的现行说明不保证腾讯服务器可用，此项目也不能保证腾讯接口的稳定性。

对每场战绩，原始对局字段 `endOfGameResult` 存在且为非空字符串时同时以 `endOfGameResult` 和兼容字段 `result` 返回。`durationSeconds` 为来源 `gameDuration`；唯一匹配查询玩家后，来源字段 `wasAfk`、`wasSevereTransgressor` 仅在严格布尔类型时返回，`timePlayed` 仅在非负有限数值时返回。缺失、无效或无法唯一匹配时省略相应字段。它们是来源字段而非维护资格结论：尤其不能将 `wasAfk=false` 当作已经确认没有挂机或中途退出。

## 限制

SGP 按页查询，最多 10 页。仅当有 `since`，且完整页的结束时间连续倒序跨过边界、没有重复对局、最后复查第一页未变化时，`complete` 才为 `true`。这只是**观测到的分页覆盖证据**，并不能证明上游没有漏记、延迟或按隐私截断，也不能证明对局符合排位维护资格；空页、不足一页、重复、乱序或页数上限均不能声称完整。因此默认**不能据此自动修改维护天数**。近期查询没有时间边界，`complete` 始终为 `false`。跨区及隐私设置下的可用性未经充分验证，不同客户端版本可能返回不同格式。

## 离线测试

```powershell
python -m unittest -v
```

测试使用合成数据，验证覆盖边界、重复页、区服与来源校验及异常处理；它不证明实际跨区、维护资格或上游完整历史可用。
