#!/usr/bin/env python3
"""Read-only local League Client match-history bridge, no third-party dependencies."""
import argparse
import base64
import datetime as dt
import json
import re
import ssl
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

UTC = dt.timezone.utc
PAGE_SIZE = 20
MAX_PAGES = 10
MAX_BODY = 4096
SERVERS = {
    'HN1': ('艾欧尼亚', 'hn1-k8s-sgp.lol.qq.com'),
    'HN10': ('黑色玫瑰', 'hn10-k8s-sgp.lol.qq.com'),
    'TJ100': ('联盟四区', 'tj100-sgp.lol.qq.com'),
    'TJ101': ('联盟五区', 'tj101-sgp.lol.qq.com'),
    'NJ100': ('联盟一区', 'nj100-sgp.lol.qq.com'),
    'GZ100': ('联盟二区', 'gz100-sgp.lol.qq.com'),
    'CQ100': ('联盟三区', 'cq100-sgp.lol.qq.com'),
    'BGP2': ('峡谷之巅', 'bgp2-k8s-sgp.lol.qq.com'),
}


class BridgeError(Exception):
    def __init__(self, message, status=502):
        super().__init__(message)
        self.status = status


def now_iso():
    return dt.datetime.now(UTC).isoformat().replace('+00:00', 'Z')


def get_credentials():
    # The child process returns secrets only through its private stdout pipe. Never log it.
    script = r'''$p=Get-CimInstance Win32_Process -Filter "name='LeagueClientUx.exe'" | Select-Object -First 1
if (!$p -or !$p.CommandLine) { exit 2 }
$c=$p.CommandLine
$port=[regex]::Match($c,'--app-port=(\d+)').Groups[1].Value
$token=[regex]::Match($c,'--remoting-auth-token=([^\s]+)').Groups[1].Value.Trim('"')
if (!$port -or !$token) { exit 3 }
@{port=$port;token=$token} | ConvertTo-Json -Compress'''
    try:
        result = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', script],
                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=10,
                                check=True, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        obj = json.loads(result.stdout.decode('utf-8-sig'))
        port = int(obj['port'])
        if not 1 <= port <= 65535 or not obj['token']:
            raise ValueError()
        return port, obj['token']
    except (OSError, subprocess.SubprocessError, ValueError, KeyError, json.JSONDecodeError):
        raise BridgeError('无法连接游戏客户端，请先打开并登录英雄联盟客户端。', 503) from None


def lcu_get(path):
    port, token = get_credentials()
    encoded = base64.b64encode(('riot:' + token).encode()).decode('ascii')
    req = urllib.request.Request('https://127.0.0.1:' + str(port) + path,
                                 headers={'Authorization': 'Basic ' + encoded, 'Accept': 'application/json'})
    # LCU uses a self-signed certificate on the loopback interface. This context is local to LCU requests.
    context = ssl._create_unverified_context()
    try:
        with urllib.request.urlopen(req, context=context, timeout=15) as response:
            return json.load(response)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise BridgeError('未找到该玩家，或当前客户端所在区服无法查询。', 404) from None
        raise BridgeError('游戏客户端拒绝了查询或数据源暂不可用。', 502) from None
    except (OSError, ValueError, json.JSONDecodeError):
        raise BridgeError('游戏客户端暂不可用，请稍后重试。', 503) from None


def parse_since(value):
    if value is None:
        return None
    if not isinstance(value, str) or len(value) > 64:
        raise BridgeError('since 必须是带时区的 ISO 时间。', 400)
    try:
        parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            raise ValueError()
        return parsed.timestamp()
    except (ValueError, OverflowError):
        raise BridgeError('since 必须是带时区的 ISO 时间。', 400) from None


def validate_riot_id(value):
    if not isinstance(value, str) or not re.fullmatch(r'[^#\r\n]{1,80}#[^#\r\n]{1,20}', value.strip()):
        raise BridgeError('请填写完整的 Riot ID，格式为游戏名#标签。', 400)
    return value.strip()


def iso_from_seconds(seconds):
    try:
        return dt.datetime.fromtimestamp(seconds, UTC).isoformat().replace('+00:00', 'Z')
    except (ValueError, OverflowError, OSError):
        raise BridgeError('战绩时间格式异常，无法安全处理。', 502) from None


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def sgp_get(host, puuid, start, token):
    if host not in {server[1] for server in SERVERS.values()}:
        raise BridgeError('服务器不受支持。', 400)
    path = '/match-history-query/v1/products/lol/player/' + urllib.parse.quote(puuid, safe='') + '/SUMMARY'
    query = urllib.parse.urlencode({'startIndex': start, 'count': PAGE_SIZE})
    req = urllib.request.Request('https://' + host + ':21019' + path + '?' + query,
                                 headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/json'})
    try:
        opener = urllib.request.build_opener(NoRedirect())
        with opener.open(req, timeout=15) as response:
            return json.load(response)
    except (OSError, ValueError, json.JSONDecodeError):
        raise BridgeError('SGP 战绩源暂不可用或拒绝查询。', 503) from None


def match_lookup(riot_id, since=None, region=None, get=lcu_get, get_sgp=sgp_get):
    name = validate_riot_id(riot_id)
    threshold = parse_since(since)
    if not isinstance(region, str) or not region.strip():
        raise BridgeError('请填写区服，并确保与当前游戏客户端所在区服一致。', 400)
    auth = get('/lol-rso-auth/v1/authorization')
    platform = auth.get('currentPlatformId', '').upper() if isinstance(auth, dict) else ''
    server = SERVERS.get(platform)
    if not server:
        raise BridgeError('当前客户端的区服暂不受支持。', 400)
    if region.strip().casefold() not in (platform.casefold(), server[0].casefold()):
        raise BridgeError('填写的区服与当前客户端区服不一致，跨区查询尚未验证。', 400)
    account = get('/lol-summoner/v1/summoners?name=' + urllib.parse.quote(name, safe=''))
    puuid = account.get('puuid') if isinstance(account, dict) else None
    if not isinstance(puuid, str) or not puuid:
        raise BridgeError('玩家身份无法解析，请检查名称及当前区服。', 404)
    returned_name, returned_tag = account.get('gameName'), account.get('tagLine')
    requested_name, requested_tag = name.rsplit('#', 1)
    if (not isinstance(returned_name, str) or not isinstance(returned_tag, str)
        or returned_name.casefold() != requested_name.casefold()
        or returned_tag.casefold() != requested_tag.casefold()):
        raise BridgeError('查询到的账号与输入的 Riot ID 不一致，已停止查询。', 404)
    entitlements = get('/entitlements/v1/token')
    token = entitlements.get('accessToken') if isinstance(entitlements, dict) else None
    if not isinstance(token, str) or not token:
        raise BridgeError('游戏客户端凭证不可用，请确认已登录。', 503)
    observed_at = now_iso()
    matches, seen = [], set()
    first_ids = None
    previous_end = None
    complete = False
    reason = '近期战绩仅供展示；未请求时间窗口。'
    for page in range(MAX_PAGES):
        start = page * PAGE_SIZE
        data = get_sgp(server[1], puuid, start, token)
        try:
            games = data['games']
            if not isinstance(games, list):
                raise TypeError()
        except (KeyError, TypeError, IndexError):
            raise BridgeError('SGP 战绩格式异常，无法确认覆盖范围。', 502) from None
        if not games:
            reason = '数据源返回空页，无法确认历史是否被截断。'
            break
        page_ids = []
        for game in games:
            if not isinstance(game, dict) or not isinstance(game.get('json'), dict):
                raise BridgeError('战绩格式异常，无法确认覆盖范围。', 502)
            game = game['json']
            gid, queue, created, ended = (game.get('gameId'), game.get('queueId'), game.get('gameCreation'), game.get('gameEndTimestamp'))
            result, game_platform = game.get('endOfGameResult'), game.get('platformId')
            if (isinstance(gid, bool) or not isinstance(gid, (int, str)) or not str(gid).isdigit()
                or isinstance(queue, bool) or not isinstance(queue, int)
                or isinstance(created, bool) or not isinstance(created, (int, float)) or created <= 0
                or isinstance(ended, bool) or not isinstance(ended, (int, float)) or ended < created
                or not isinstance(result, str) or not result
                or not isinstance(game_platform, str) or game_platform.upper() != platform):
                raise BridgeError('战绩缺少对局编号、队列或结束时间，无法确认覆盖范围。', 502)
            gid = str(gid)
            page_ids.append(gid)
            if gid in seen or (previous_end is not None and ended > previous_end):
                reason = '战绩存在重复或时间乱序，无法确认覆盖范围。'
                return {'ok': True, 'matches': matches, 'complete': False, 'reason': reason, 'observedAt': observed_at, 'source': 'SGP', 'region': platform}
            seen.add(gid)
            previous_end = ended
            start_ts, end_ts = created / 1000, ended / 1000
            if threshold is None or end_ts >= threshold:
                matches.append({'gameId': gid, 'queueId': queue, 'startedAt': iso_from_seconds(start_ts), 'endedAt': iso_from_seconds(end_ts), 'result': result})
        if page == 0:
            first_ids = page_ids
        if threshold is None:
            break
        if len(games) != PAGE_SIZE:
            reason = '数据源返回不足一页，无法确认历史是否被截断。'
            break
        if previous_end / 1000 < threshold:
            again = get_sgp(server[1], puuid, 0, token)
            try:
                latest_ids = [str(x['json']['gameId']) for x in again['games']]
            except (TypeError, KeyError):
                raise BridgeError('复查战绩格式异常，无法确认覆盖范围。', 502) from None
            if latest_ids != first_ids:
                reason = '查询期间最新战绩发生变化，请重新查询。'
                break
            complete = True
            reason = '分页已跨过时间边界并通过重复和顺序检查；仍取决于数据源是否遗漏或延迟。'
            break
    else:
        reason = '已达到查询页数上限，历史记录可能不完整。'
    return {'ok': True, 'matches': matches, 'complete': complete, 'reason': reason, 'observedAt': observed_at, 'source': 'SGP', 'region': platform}


def origin_valid(origin):
    try:
        u = urllib.parse.urlsplit(origin)
        return (u.scheme == 'https' and u.hostname and u.hostname.lower().endswith('.github.io') and u.port in (None, 443)
                or u.scheme == 'http' and u.hostname in ('localhost', '127.0.0.1') and u.port is not None) and not u.path and not u.query and not u.fragment and not u.username and not u.password
    except ValueError:
        return False


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # Requests and player names never enter access logs.

    def authorized(self):
        return self.headers.get('Host') == '127.0.0.1:' + str(self.server.server_port) and self.headers.get('Origin') == self.server.allowed_origin

    def respond(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        self.send_response(status)
        if self.authorized():
            self.send_header('Access-Control-Allow-Origin', self.server.allowed_origin)
            self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        if not self.authorized() or self.path not in ('/api/status', '/api/matches'):
            return self.respond(403, {'ok': False, 'error': '来源未获允许。'})
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', self.server.allowed_origin)
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Vary', 'Origin')
        self.send_header('Content-Length', '0')
        self.end_headers()

    def do_GET(self):
        if not self.authorized():
            return self.respond(403, {'ok': False, 'error': '来源未获允许。'})
        if self.path != '/api/status':
            return self.respond(404, {'ok': False, 'error': '接口不存在。'})
        try:
            lcu_get('/lol-summoner/v1/current-summoner')
            return self.respond(200, {'ok': True, 'clientDetected': True})
        except BridgeError as e:
            return self.respond(e.status, {'ok': False, 'error': str(e)})

    def do_POST(self):
        if not self.authorized():
            return self.respond(403, {'ok': False, 'error': '来源未获允许。'})
        if self.path != '/api/matches':
            return self.respond(404, {'ok': False, 'error': '接口不存在。'})
        if self.headers.get('Content-Type', '').split(';')[0].strip().lower() != 'application/json':
            return self.respond(400, {'ok': False, 'error': '请求必须使用 JSON。'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length < 2 or length > MAX_BODY:
                raise ValueError()
            data = json.loads(self.rfile.read(length).decode('utf-8'))
            if not isinstance(data, dict) or set(data) - {'riotId', 'since', 'region'}:
                raise ValueError()
            result = match_lookup(data.get('riotId'), data.get('since'), data.get('region'))
            return self.respond(200, result)
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            return self.respond(400, {'ok': False, 'error': '请求格式不正确。'})
        except BridgeError as e:
            return self.respond(e.status, {'ok': False, 'complete': False, 'error': str(e)})


def main():
    parser = argparse.ArgumentParser(description='仅在本机运行的只读战绩桥接。')
    parser.add_argument('--allow-origin', required=True, help='允许访问的唯一网站 origin，例如 https://USER.github.io')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    if not origin_valid(args.allow_origin) or not 1024 <= args.port <= 65535:
        parser.error('origin 必须是 https://*.github.io 或带端口的本机开发地址；端口须在 1024–65535。')
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    server.allowed_origin = args.allow_origin
    print('只读桥接已启动，监听 127.0.0.1:' + str(args.port) + '。按 Ctrl+C 退出。', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
