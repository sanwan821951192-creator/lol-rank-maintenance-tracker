import { test } from 'node:test'
import assert from 'node:assert/strict'
import { replay } from '../replay.mjs'

function sample() {
  const account = { id: 'sample', name: '玩家#CN1', region: '示例区', queue: '单双排', tier: '大师及以上', days: 13, baselineDate: '2026-10-30', revision: 1 }
  const setup = {
    binding: { confirmed: true, accountId: 'sample', puuid: 'synthetic-puuid', serverId: 'SYNTHETIC', regionLabel: '示例区', riotId: account.name, queue: '单双排' },
    baseline: { confirmed: true, accountId: 'sample', revision: 1, days: 13, baselineDate: '2026-10-30', at: '2026-10-30T12:00:00Z' },
    targetAt: '2026-10-31T15:55:00Z',
    rule: { confirmed: true, tier: '大师及以上', gainPerGame: 1, cap: 14, dailyDecrease: 1, offsetMinutes: 480, settlementHour: 23, settlementMinute: 55, queueIds: [999] }
  }
  const history = {
    ok: true, complete: true, source: 'SGP', identityVerified: true,
    identity: { puuid: 'synthetic-puuid', serverId: 'SYNTHETIC', riotId: account.name },
    coverageVerified: true, noMissingMatchesVerified: true,
    coverageStart: '2026-10-30T12:00:00Z', coverageEnd: '2026-10-31T15:55:00Z', observedAt: '2026-10-31T16:00:00Z',
    matches: []
  }
  return { account, setup, history }
}

test('chronological replay respects cap, settlements, queue, and deduplicates games', () => {
  const { account, setup, history } = sample()
  const game = { gameId: '1', queueId: 999, endedAt: '2026-10-30T14:00:00Z', endTimeVerified: true, eligibilityVerified: true, maintenanceEligible: true }
  history.matches = [game, { ...game }, { gameId: '2', queueId: 123, endedAt: '2026-10-31T12:00:00Z', endTimeVerified: true }]
  const result = replay(account, setup, history)
  assert.equal(result.status, 'candidate')
  assert.equal(result.days, 12) // 13 -> 14 -> 13 -> 12
  assert.equal(result.games, 1)
  assert.equal(result.settlements, 2)
})

test('user-provided diamond example: synthetic one game adds one, cap 28', () => {
  const { account, setup, history } = sample()
  account.tier = setup.rule.tier = '钻石'; account.days = setup.baseline.days = 28; setup.rule.cap = 28
  history.matches = [{ gameId: '1', queueId: 999, endedAt: '2026-10-30T14:00:00Z', endTimeVerified: true, eligibilityVerified: true, maintenanceEligible: true }]
  assert.equal(replay(account, setup, history).days, 26)
})

test('missing critical evidence fails closed, including actual bridge-shaped output', () => {
  const { account, setup, history } = sample()
  assert.equal(replay(account, setup, { ok: true, complete: true, matches: [], observedAt: history.observedAt, source: 'SGP', region: 'SYNTHETIC' }).status, 'skipped')
  for (const broken of [
    { ...history, complete: false }, { ...history, coverageVerified: false },
    { ...history, noMissingMatchesVerified: false }, { ...history, coverageStart: '2026-10-30T13:00:00Z' },
    { ...history, identity: { ...history.identity, puuid: 'different' } },
    { ...history, matches: [{ gameId: '1', queueId: 999, endedAt: '2026-10-30T14:00:00Z' }] },
    { ...history, matches: [{ gameId: '1', queueId: 999, endedAt: '2026-10-30T14:00:00Z', endTimeVerified: true }] }
  ]) assert.equal(replay(account, setup, broken).status, 'skipped')
  assert.equal(replay(account, { ...setup, baseline: { ...setup.baseline, at: undefined } }, history).status, 'skipped')
  assert.equal(replay(account, { ...setup, rule: { ...setup.rule, confirmed: false } }, history).status, 'skipped')
  assert.equal(replay({ ...account, revision: 2 }, setup, history).status, 'skipped')
  assert.equal(replay({ ...account, region: '其他区' }, setup, history).status, 'skipped')
  assert.equal(replay({ ...account, queue: '未知' }, setup, history).status, 'skipped')
})

test('conflicting duplicate games and ambiguous settlement ordering fail closed', () => {
  const { account, setup, history } = sample()
  const match = { gameId: '1', queueId: 999, endedAt: '2026-10-30T14:00:00Z', endTimeVerified: true, eligibilityVerified: true, maintenanceEligible: true }
  history.matches = [match, { ...match, endedAt: '2026-10-30T14:01:00Z' }]
  assert.equal(replay(account, setup, history).status, 'skipped')
  history.matches = [{ ...match, endedAt: '2026-10-30T15:55:00Z' }]
  assert.equal(replay(account, setup, history).status, 'skipped')
  history.matches = [{ ...match, endedAt: setup.baseline.at }]
  assert.equal(replay(account, setup, history).status, 'skipped')
})
