// An intentionally read-only calculation. Nothing here writes shared records.
const iso = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z$/
const DAY = 86400000
const fail = (reason) => ({ status: 'skipped', reason })

function instant(value) {
  if (typeof value !== 'string' || !iso.test(value)) return NaN
  const time = Date.parse(value)
  if (!Number.isFinite(time)) return NaN
  // Round-trip the UTC calendar fields; reject normalized invalid dates.
  const canonical = new Date(time).toISOString()
  return canonical.slice(0, 19) === value.slice(0, 19) ? time : NaN
}

function validRule(r) {
  return r?.confirmed === true && typeof r.tier === 'string' && r.tier !== '未知' &&
    Number.isInteger(r.gainPerGame) && r.gainPerGame >= 0 && r.gainPerGame <= 365 &&
    Number.isInteger(r.cap) && r.cap >= 0 && r.cap <= 365 &&
    Number.isInteger(r.dailyDecrease) && r.dailyDecrease >= 0 && r.dailyDecrease <= 365 &&
    Array.isArray(r.queueIds) && r.queueIds.length > 0 &&
    r.queueIds.every(v => Number.isSafeInteger(v) && v > 0) &&
    Number.isInteger(r.offsetMinutes) && Math.abs(r.offsetMinutes) <= 840 &&
    Number.isInteger(r.settlementHour) && r.settlementHour >= 0 && r.settlementHour <= 23 &&
    Number.isInteger(r.settlementMinute) && r.settlementMinute >= 0 && r.settlementMinute <= 59
}

function isSettlement(time, r) {
  const local = new Date(time + r.offsetMinutes * 60000)
  return local.getUTCHours() === r.settlementHour && local.getUTCMinutes() === r.settlementMinute &&
    local.getUTCSeconds() === 0 && local.getUTCMilliseconds() === 0
}

/**
 * account is a shared API record; setup is independently confirmed evidence;
 * history is a future bridge contract, not today's unverified bridge output.
 */
export function replay(account, setup, history) {
  if (!account || !setup || !history) return fail('缺少账号、配置或战绩。')
  const { rule, binding, baseline, targetAt } = setup
  if (!validRule(rule)) return fail('维护规则或结算时间未完整确认。')
  if (account.tier !== rule.tier || account.queue === '未知' || account.tier === '未知') return fail('记录中的段位或队列不匹配已确认规则。')
  if (!binding || binding.confirmed !== true || !binding.puuid || !binding.serverId ||
      binding.accountId !== account.id || binding.regionLabel !== account.region ||
      binding.riotId !== account.name || binding.queue !== account.queue) return fail('账号、大区或队列身份尚未确认。')
  if (!baseline || baseline.confirmed !== true || baseline.revision !== account.revision ||
      baseline.days !== account.days || baseline.accountId !== account.id ||
      baseline.baselineDate !== account.baselineDate) return fail('精确基准与当前记录或版本不匹配。')
  const start = instant(baseline.at), end = instant(targetAt)
  if (!Number.isFinite(start) || !Number.isFinite(end) || start >= end) return fail('缺少有效的精确基准时间或目标时间。')
  if (new Date(start + rule.offsetMinutes * 60000).toISOString().slice(0, 10) !== account.baselineDate) return fail('精确基准时间与记录日期不一致。')
  if (end - start > 366 * DAY) return fail('回放区间过长，需要重新核对基准。')
  if (!isSettlement(end, rule)) return fail('目标时间不是已确认的结算时刻。')
  if (!Number.isInteger(account.days) || account.days < 0 || account.days > rule.cap) return fail('基准天数不在已确认规则范围内。')
  if (history.ok !== true || history.complete !== true || history.source !== 'SGP' ||
      history.identityVerified !== true || !history.identity ||
      history.identity.puuid !== binding.puuid || history.identity.serverId !== binding.serverId ||
      history.identity.riotId !== binding.riotId) return fail('战绩不完整或账号身份缺少可核验证据。')
  if (history.coverageVerified !== true || history.noMissingMatchesVerified !== true ||
      instant(history.coverageStart) > start ||
      instant(history.coverageEnd) < end || !Number.isFinite(instant(history.coverageStart)) ||
      !Number.isFinite(instant(history.coverageEnd)) || instant(history.observedAt) < end ||
      !Number.isFinite(instant(history.observedAt)) || !Array.isArray(history.matches)) {
    return fail('缺少覆盖完整区间的可靠证据。')
  }

  const byId = new Map()
  for (const match of history.matches) {
    if (!/^[A-Za-z0-9_-]{1,100}$/.test(String(match?.gameId ?? '')) ||
        !Number.isSafeInteger(match.queueId) || match.queueId <= 0 ||
        match.endTimeVerified !== true || !Number.isFinite(instant(match.endedAt))) {
      return fail('对局 ID、队列或精确结束时间不完整。')
    }
    if (rule.queueIds.includes(match.queueId) &&
        (match.eligibilityVerified !== true || typeof match.maintenanceEligible !== 'boolean')) {
      return fail('无法确认排位对局是否计入维护。')
    }
    const key = String(match.gameId)
    const entry = { gameId: key, queueId: match.queueId, endedAt: match.endedAt, time: instant(match.endedAt), maintenanceEligible: match.maintenanceEligible }
    const old = byId.get(key)
    if (old && (old.queueId !== entry.queueId || old.time !== entry.time || old.maintenanceEligible !== entry.maintenanceEligible)) return fail('同一对局出现冲突数据。')
    byId.set(key, entry)
  }

  const events = []
  const settlementAtLocalDay = rule.settlementHour * 3600000 + rule.settlementMinute * 60000
  const firstLocalDay = Math.floor((start + rule.offsetMinutes * 60000) / DAY)
  const lastLocalDay = Math.floor((end + rule.offsetMinutes * 60000) / DAY)
  for (let day = firstLocalDay; day <= lastLocalDay; day++) {
    const time = day * DAY + settlementAtLocalDay - rule.offsetMinutes * 60000
    if (time > start && time <= end) events.push({ time, type: 'settlement' })
  }
  const relevant = [...byId.values()].filter(m => rule.queueIds.includes(m.queueId) && m.maintenanceEligible && m.time > start && m.time <= end)
  if ([...byId.values()].some(m => rule.queueIds.includes(m.queueId) && m.maintenanceEligible && m.time === start)) return fail('对局和基准时刻重合，先后顺序无法确认。')
  for (const match of relevant) {
    if (isSettlement(match.time, rule)) return fail('对局和结算时间重合，先后顺序无法确认。')
    events.push({ time: match.time, type: 'game', gameId: match.gameId })
  }
  events.sort((a, b) => a.time - b.time || a.type.localeCompare(b.type) || String(a.gameId).localeCompare(String(b.gameId)))
  let days = account.days
  for (const event of events) {
    days = event.type === 'game' ? Math.min(rule.cap, days + rule.gainPerGame) : Math.max(0, days - rule.dailyDecrease)
  }
  return { status: 'candidate', days, targetAt, baselineRevision: account.revision,
    games: relevant.length, settlements: events.filter(e => e.type === 'settlement').length,
    note: '仅供核对，不会写入共享数据。' }
}
