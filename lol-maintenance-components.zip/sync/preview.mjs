import { readFile } from 'node:fs/promises'
import { replay } from './replay.mjs'

// Only GET the shared API and read-only POST to the local match bridge. No PUT/DELETE.
async function main() {
  const filename = process.argv[2]
  if (!filename) throw new Error('用法：node preview.mjs 配置文件.json')
  const config = JSON.parse(await readFile(filename, 'utf8'))
  const api = new URL(config.apiBase)
  if (api.protocol !== 'https:' && !(api.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(api.hostname))) {
    throw new Error('共享 API 必须使用 HTTPS 或本机地址。')
  }
  api.pathname = api.pathname.replace(/\/$/, '') + '/api/accounts'
  const accountsResponse = await fetch(api, { signal: AbortSignal.timeout(10000) })
  if (!accountsResponse.ok) throw new Error(`共享 API 不可用（${accountsResponse.status}）。`)
  const accounts = (await accountsResponse.json()).accounts
  if (!Array.isArray(accounts)) throw new Error('共享 API 响应格式不正确。')
  if (!Array.isArray(config.setups)) throw new Error('缺少 setups 配置。')
  const results = []
  for (const setup of config.setups) {
    const account = accounts.find(a => a.id === setup?.binding?.accountId)
    if (!account) { results.push({ accountId: setup?.binding?.accountId, status: 'skipped', reason: '共享记录不存在。' }); continue }
    // Avoid even querying the bridge until the user supplies an exact baseline.
    if (!setup.baseline?.at || setup.baseline.revision !== account.revision) {
      results.push({ accountId: account.id, status: 'skipped', reason: '精确基准时间缺失或版本不匹配。' }); continue
    }
    try {
      const response = await fetch('http://127.0.0.1:8765/api/matches', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ riotId: account.name, since: setup.baseline.at, region: setup.binding.serverId }),
        signal: AbortSignal.timeout(30000)
      })
      if (!response.ok) throw new Error(`本机桥返回 ${response.status}`)
      const history = await response.json()
      results.push({ accountId: account.id, ...replay(account, setup, history) })
    } catch (error) {
      results.push({ accountId: account.id, status: 'skipped', reason: `本机桥不可用：${error.message}` })
    }
  }
  console.log(JSON.stringify({ mode: 'preview-only', results }, null, 2))
}

main().catch(error => { console.error(error.message); process.exitCode = 1 })
