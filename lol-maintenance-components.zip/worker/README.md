# 共享数据后端

这是 GitHub Pages 网站使用的 Cloudflare Worker + D1 后端。静态页面提供界面，Worker 负责校验请求和读写 D1；它们是两个需要分别部署的部分。此目录不包含真实账号数据、凭据或生产数据库编号。

## 部署前提

1. 注册并登录 Cloudflare，启用 Workers 和 D1。免费额度和可用性以 Cloudflare 当前说明为准：[D1 定价](https://developers.cloudflare.com/d1/platform/pricing/)、[Workers 定价](https://developers.cloudflare.com/workers/platform/pricing/)。
2. 安装包含 npm 和 npx 的 Node.js。以下命令在 PowerShell 中、此 `worker` 目录执行。当前仓库的 `database_id` 是占位符，必须替换。

```powershell
npx wrangler login
npx wrangler d1 create lol-maintenance
```

将创建命令输出的数据库 ID 填入 `wrangler.toml` 的 `database_id`。不要填写访问令牌。

```powershell
npx wrangler d1 execute lol-maintenance --remote --file=./schema.sql
npx wrangler deploy
```

部署成功后，复制 Wrangler 给出的 Worker 根地址，填入前端配置的 `API_BASE`，然后发布前端到 GitHub Pages。部署后可以请求 `https://你的-worker-地址/api/accounts`，初始应返回 `{"accounts":[]}`。本地测试可运行 `node --test test/*.test.js`（Node.js 版本需支持 `node:sqlite`）。本地测试不等于已验证云端部署。

已有数据库不要再次执行新建用的 `schema.sql` 来代替迁移。先备份并确认目标数据库，再对使用原始 schema 的数据库执行一次 `migrations/0001_precise_baseline_estimate.sql`，之后部署新 Worker；该增量迁移不会猜测旧记录的精确时刻。不要对已经按新 `schema.sql` 创建的库执行此迁移，也不要重复执行该迁移。

## 数据及访问方式

API 允许所有访客跨域读取、新增、修改及删除账号记录，无需登录。它因此适用于有意公开编辑的共享清单：任何知道地址的人也可修改、删除或批量写入数据。版本号只能避免意外覆盖，不能阻止恶意操作；若以后需要可靠归属、访问控制、审计和防滥用，需要另外增加身份验证、限流和备份。不要把游戏密码、客户端令牌或其他私密信息写入账号、备注、GitHub、前端配置或 Worker 日志。

接口统一使用 JSON，`Content-Type: application/json`。时间是 ISO 8601 UTC，`baselineDate` 是人工输入基准日期（`YYYY-MM-DD`）。

| 请求 | 用途 | 成功结果 |
| --- | --- | --- |
| `GET /api/accounts` | 读取全部记录 | `{"accounts":[...]}` |
| `POST /api/accounts` | 新增记录 | HTTP 201，`{"account":{...}}` |
| `PUT /api/accounts/{id}` | 更新已有记录，提交完整字段及 `revision` | `{"account":{...}}` |
| `POST /api/accounts/{id}/estimate` | 以当前 `revision` 条件保存独立估算结果 | `{"account":{...}}` |
| `DELETE /api/accounts/{id}` | 删除记录，请求体为 `{"revision":1}` | `{"ok":true}` |

新增及更新字段：`name`（1–100 字符）、`region`（1–50 字符）、`queue`（`单双排` / `灵活组排` / `未知`）、`tier`（`钻石` / `大师及以上` / `未知`）、`days`（0–365 整数）、`baselineDate`（有效日期）、`note`（0–300 字符）。更新和删除使用读取到的整数 `revision`。版本不符返回 HTTP 409，需要重新读取后再决定如何处理；记录不存在返回 404，输入错误返回 400。错误格式为 `{"error":{"code":"...","message":"..."}}`。

新增和更新还可提交 `baselineAt`：人工确认的精确时间，使用 UTC ISO 8601（例如 `2025-01-01T16:30:00Z`）；它对应的北京时间日期必须与 `baselineDate` 一致。`null` 表示未知。旧客户端省略该字段时，只有账号、区服、队列、段位、天数和日期均未变才保留原基准时刻，否则清空。任何普通 PUT 都清空已有估算，以免基准改变后展示陈旧结果。

估算请求体示例：`{"revision":1,"candidateDays":8,"candidateAt":"2025-01-03T03:00:00Z","candidateSummary":"候选结果，资格未核实","candidateReviews":{"123":{"include":true,"wasAfk":null,"endedAt":"2025-01-02T00:00:00Z"}}}`。`candidateDays` 为 0–365 的整数；`candidateAt` 不得早于精确基准或晚于服务端当前时间；`candidateSummary` 为 1–2000 字符的非空文本。记录必须已有精确基准。`candidateReviews` 必填（无对局时使用 `{}`），最多 200 条，每个键是最多 40 位的数字对局 ID；值只允许 `include`（布尔）、`wasAfk`（布尔或 null）和 `endedAt`（UTC 时刻，须晚于基准并不晚于查询时刻）。普通 PUT 会清除估算与核对记录。请求体上限 64 KiB。

保存成功后返回 `candidateDays`、`candidateAt`、`candidateStatus: "estimate"`、`candidateSummary` 和已保存的 `candidateReviews` 对象。这些字段和人工基准 `days`、`baselineDate`、`baselineAt` 分开存储；版本冲突返回 409。估算字段由访问者提供，Worker 不连接战绩服务，也不验证其计算或对局资格；因此它们不是官方维护天数或核实证据。任何访客都可以修改，版本号只用于防止意外覆盖。
