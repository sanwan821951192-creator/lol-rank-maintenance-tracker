# 共享数据后端

这是 GitHub Pages 网站使用的 Cloudflare Worker + D1 后端。静态页面提供界面，Worker 负责校验请求和读写 D1；它们是两个需要分别部署的部分。此目录不包含真实账号数据、凭据或生产数据库编号。

## 部署前提

1. 注册并登录 Cloudflare，启用 Workers 和 D1。免费额度和可用性以 Cloudflare 当前说明为准：[D1 定价](https://developers.cloudflare.com/d1/platform/pricing/)、[Workers 定价](https://developers.cloudflare.com/workers/platform/pricing/)。
2. 安装包含 npm 和 npx 的 Node.js。以下命令在 PowerShell 中、此 `worker` 目录执行。当前仓库的 `database_id` 是占位符，必须替换。

```powershell
npx wrangler login
npx wrangler d1 create lol-maintenance
```

将创建命令输出的数据库 ID 填入 `wrangler.toml` 的 `database_id`。不要填写访问令牌。

```powershell
npx wrangler d1 execute lol-maintenance --remote --file=./schema.sql
npx wrangler deploy
```

部署成功后，复制 Wrangler 给出的 Worker 根地址，填入前端配置的 `API_BASE`，然后发布前端到 GitHub Pages。部署后可以请求 `https://你的-worker-地址/api/accounts`，初始应返回 `{"accounts":[]}`。本地测试可运行 `node --test test/*.test.js`（Node.js 版本需支持 `node:sqlite`）。本地测试不等于已验证云端部署。

## 数据及访问方式

API 允许所有访客跨域读取、新增、修改及删除账号记录，无需登录。它因此适用于有意公开编辑的共享清单：任何知道地址的人也可修改、删除或批量写入数据。版本号只能避免意外覆盖，不能阻止恶意操作；若以后需要可靠归属、访问控制、审计和防滥用，需要另外增加身份验证、限流和备份。不要把游戏密码、客户端令牌或其他私密信息写入账号、备注、GitHub、前端配置或 Worker 日志。

接口统一使用 JSON，`Content-Type: application/json`。时间是 ISO 8601 UTC，`baselineDate` 是人工输入基准日期（`YYYY-MM-DD`）。

| 请求 | 用途 | 成功结果 |
| --- | --- | --- |
| `GET /api/accounts` | 读取全部记录 | `{"accounts":[...]}` |
| `POST /api/accounts` | 新增记录 | HTTP 201，`{"account":{...}}` |
| `PUT /api/accounts/{id}` | 更新已有记录，提交完整字段及 `revision` | `{"account":{...}}` |
| `DELETE /api/accounts/{id}` | 删除记录，请求体为 `{"revision":1}` | `{"ok":true}` |

新增及更新字段：`name`（1–100 字符）、`region`（1–50 字符）、`queue`（`单双排` / `灵活组排` / `未知`）、`tier`（`钻石` / `大师及以上` / `未知`）、`days`（0–365 整数）、`baselineDate`（有效日期）、`note`（0–300 字符）。更新和删除使用读取到的整数 `revision`。版本不符返回 HTTP 409，需要重新读取后再决定如何处理；记录不存在返回 404，输入错误返回 400。错误格式为 `{"error":{"code":"...","message":"..."}}`。

该后端目前只存取人工输入的基准数据，不连接 Akari、不执行战绩查询，也不自动判断是否完成维护。实际查询可用后需要单独接入，并明确失败、延迟和未知状态。
