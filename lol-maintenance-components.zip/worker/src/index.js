const HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff'
}

const COLUMNS = `id, name, region, queue, tier, days,
  baseline_date AS baselineDate, note, revision,
  created_at AS createdAt, updated_at AS updatedAt`
const QUEUES = new Set(['单双排', '灵活组排', '未知'])
const TIERS = new Set(['钻石', '大师及以上', '未知'])
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...HEADERS, 'Content-Type': 'application/json; charset=utf-8' }
  })
}

function error(status, code, message) {
  return json({ error: { code, message } }, status)
}

function isDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const parsed = new Date(`${value}T00:00:00Z`)
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value
}

function validate(input, needsRevision) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return null
  const { name, region, queue, tier, days, baselineDate, note, revision } = input
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 100 ||
      typeof region !== 'string' || !region.trim() || region.trim().length > 50 ||
      !QUEUES.has(queue) || !TIERS.has(tier) ||
      !Number.isInteger(days) || days < 0 || days > 365 || !isDate(baselineDate) ||
      typeof note !== 'string' || note.length > 300 ||
      (needsRevision && (!Number.isSafeInteger(revision) || revision < 1))) return null
  return { name: name.trim(), region: region.trim(), queue, tier, days, baselineDate, note, revision }
}

async function readBody(request) {
  if (!/^application\/json(?:\s*;|\s*$)/i.test(request.headers.get('Content-Type') || '')) return null
  // A header check also avoids reading clearly oversized requests into memory.
  const length = request.headers.get('Content-Length')
  if (length && Number(length) > 16384) return null
  const text = await request.text()
  if (new TextEncoder().encode(text).length > 16384) return null
  try { return JSON.parse(text) } catch { return null }
}

async function getAccount(db, id) {
  return db.prepare(`SELECT ${COLUMNS} FROM accounts WHERE id = ?`).bind(id).first()
}

async function missingOrConflict(db, id) {
  const found = await db.prepare('SELECT id FROM accounts WHERE id = ?').bind(id).first()
  return found
    ? error(409, 'CONFLICT', '数据已被其他人修改，请刷新后重试。')
    : error(404, 'NOT_FOUND', '账号记录不存在。')
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: HEADERS })
    if (!env.DB) return error(503, 'DATABASE_UNAVAILABLE', '共享数据库尚未配置。')
    const url = new URL(request.url)
    const path = url.pathname.replace(/\/$/, '')
    const match = path.match(/^\/api\/accounts\/([^/]+)$/)
    try {
      if (path === '/api/accounts' && request.method === 'GET') {
        const result = await env.DB.prepare(`SELECT ${COLUMNS} FROM accounts ORDER BY updated_at DESC, id`).all()
        return json({ accounts: result.results || [] })
      }
      if (path === '/api/accounts' && request.method === 'POST') {
        const data = validate(await readBody(request), false)
        if (!data) return error(400, 'INVALID_INPUT', '请检查账号、大区、排位类型、段位、天数及日期。')
        const id = crypto.randomUUID()
        const now = new Date().toISOString()
        await env.DB.prepare(`INSERT INTO accounts
          (id,name,region,queue,tier,days,baseline_date,note,revision,created_at,updated_at)
          VALUES (?,?,?,?,?,?,?,?,1,?,?)`)
          .bind(id, data.name, data.region, data.queue, data.tier, data.days, data.baselineDate, data.note, now, now).run()
        return json({ account: await getAccount(env.DB, id) }, 201)
      }
      if (match && UUID.test(match[1]) && request.method === 'PUT') {
        const data = validate(await readBody(request), true)
        if (!data) return error(400, 'INVALID_INPUT', '请检查输入内容和记录版本。')
        const now = new Date().toISOString()
        const result = await env.DB.prepare(`UPDATE accounts SET name=?,region=?,queue=?,tier=?,days=?,
          baseline_date=?,note=?,revision=revision+1,updated_at=? WHERE id=? AND revision=?`)
          .bind(data.name, data.region, data.queue, data.tier, data.days, data.baselineDate, data.note, now, match[1], data.revision).run()
        if (!result.meta?.changes) return await missingOrConflict(env.DB, match[1])
        return json({ account: await getAccount(env.DB, match[1]) })
      }
      if (match && UUID.test(match[1]) && request.method === 'DELETE') {
        const body = await readBody(request)
        if (!body || !Number.isSafeInteger(body.revision) || body.revision < 1) {
          return error(400, 'INVALID_INPUT', '删除时需要提供有效的记录版本。')
        }
        const result = await env.DB.prepare('DELETE FROM accounts WHERE id=? AND revision=?')
          .bind(match[1], body.revision).run()
        if (!result.meta?.changes) return await missingOrConflict(env.DB, match[1])
        return json({ ok: true })
      }
      return error(404, 'NOT_FOUND', '接口不存在。')
    } catch {
      return error(500, 'SERVER_ERROR', '共享数据暂时不可用，请稍后重试。')
    }
  }
}
