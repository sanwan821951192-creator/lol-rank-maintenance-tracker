import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { DatabaseSync } from 'node:sqlite'
import worker from '../src/index.js'

// Exercise the actual SQL and Worker handler against an isolated in-memory SQLite database.
function database() {
  const sqlite = new DatabaseSync(':memory:')
  sqlite.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'))
  return {
    prepare(sql) {
      return {
        args: [],
        bind(...args) { this.args = args; return this },
        async first() { return sqlite.prepare(sql).get(...this.args) || null },
        async all() { return { results: sqlite.prepare(sql).all(...this.args) } },
        async run() { return { meta: { changes: Number(sqlite.prepare(sql).run(...this.args).changes) } } }
      }
    }
  }
}

const example = {
  name: '示例玩家#CN1', region: '艾欧尼亚', queue: '单双排', tier: '大师及以上',
  days: 7, baselineDate: '2026-10-30', note: ''
}

function request(path, method = 'GET', body) {
  return new Request('https://example.invalid' + path, {
    method, ...(body === undefined ? {} : { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
  })
}

test('create, list, update and delete with revision conflicts', async () => {
  const env = { DB: database() }
  let res = await worker.fetch(request('/api/accounts', 'POST', example), env)
  assert.equal(res.status, 201)
  assert.equal(res.headers.get('Access-Control-Allow-Origin'), '*')
  let { account } = await res.json()
  assert.equal(account.revision, 1)
  assert.equal(account.name, example.name)
  res = await worker.fetch(request('/api/accounts'), env)
  assert.equal((await res.json()).accounts.length, 1)
  res = await worker.fetch(request(`/api/accounts/${account.id}`, 'PUT', { ...example, days: 8, revision: 1 }), env)
  assert.equal(res.status, 200)
  account = (await res.json()).account
  assert.equal(account.revision, 2)
  assert.equal(account.days, 8)
  res = await worker.fetch(request(`/api/accounts/${account.id}`, 'PUT', { ...example, revision: 1 }), env)
  assert.equal(res.status, 409)
  assert.equal((await res.json()).error.code, 'CONFLICT')
  res = await worker.fetch(request(`/api/accounts/${account.id}`, 'DELETE', { revision: 1 }), env)
  assert.equal(res.status, 409)
  res = await worker.fetch(request(`/api/accounts/${account.id}`, 'DELETE', { revision: 2 }), env)
  assert.deepEqual(await res.json(), { ok: true })
  res = await worker.fetch(request(`/api/accounts/${account.id}`, 'DELETE', { revision: 2 }), env)
  assert.equal(res.status, 404)
})

test('rejects invalid dates, values, content type and oversized bodies', async () => {
  const env = { DB: database() }
  for (const input of [
    { ...example, baselineDate: '2026-02-30' },
    { ...example, days: -1 }, { ...example, days: 1.2 },
    { ...example, name: '  ' }, { ...example, tier: '王者' },
    { ...example, note: 'a'.repeat(301) }
  ]) {
    assert.equal((await worker.fetch(request('/api/accounts', 'POST', input), env)).status, 400)
  }
  assert.equal((await worker.fetch(new Request('https://example.invalid/api/accounts', {
    method: 'POST', body: JSON.stringify(example)
  }), env)).status, 400)
  assert.equal((await worker.fetch(request('/api/accounts', 'POST', { ...example, extra: 'a'.repeat(17000) }), env)).status, 400)
  assert.equal((await worker.fetch(request('/api/accounts'), env)).status, 200)
})

test('preflight and unavailable database return useful responses', async () => {
  const preflight = await worker.fetch(request('/api/accounts', 'OPTIONS'), {})
  assert.equal(preflight.status, 204)
  assert.match(preflight.headers.get('Access-Control-Allow-Methods'), /PUT/)
  const res = await worker.fetch(request('/api/accounts'), {})
  assert.equal(res.status, 503)
  assert.equal((await res.json()).error.code, 'DATABASE_UNAVAILABLE')
})

test('simultaneous edits from the same revision cannot silently overwrite each other', async () => {
  const env = { DB: database() }
  const created = await worker.fetch(request('/api/accounts', 'POST', example), env)
  const { account } = await created.json()
  const edits = await Promise.all([8, 9].map(days =>
    worker.fetch(request(`/api/accounts/${account.id}`, 'PUT', { ...example, days, revision: 1 }), env)))
  assert.deepEqual(edits.map(res => res.status).sort(), [200, 409])
  const list = await worker.fetch(request('/api/accounts'), env)
  const saved = (await list.json()).accounts[0]
  assert.equal(saved.revision, 2)
  assert.ok(saved.days === 8 || saved.days === 9)
})

test('schema rejects duplicate record ids', () => {
  const sqlite = new DatabaseSync(':memory:')
  sqlite.exec(readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'))
  const insert = sqlite.prepare('INSERT INTO accounts VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
  const values = ['id', 'name', 'region', '单双排', '未知', 1, '2026-10-30', '', 1, 'now', 'now']
  insert.run(...values)
  assert.throws(() => insert.run(...values), /UNIQUE constraint failed/)
})
