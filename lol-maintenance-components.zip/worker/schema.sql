CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  region TEXT NOT NULL CHECK (length(region) BETWEEN 1 AND 50),
  queue TEXT NOT NULL CHECK (queue IN ('单双排', '灵活组排', '未知')),
  tier TEXT NOT NULL CHECK (tier IN ('钻石', '大师及以上', '未知')),
  days INTEGER NOT NULL CHECK (days BETWEEN 0 AND 365),
  baseline_date TEXT NOT NULL,
  note TEXT NOT NULL CHECK (length(note) <= 300),
  revision INTEGER NOT NULL CHECK (revision >= 1),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS accounts_updated_at ON accounts(updated_at DESC);
